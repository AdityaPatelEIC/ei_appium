from .controller import *
from .wifi import *
from .quick_settings import *
from .appium_controller import *
setup_ad()