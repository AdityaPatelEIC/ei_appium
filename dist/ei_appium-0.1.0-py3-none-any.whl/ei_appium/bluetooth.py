class Bluetooth:
    pass